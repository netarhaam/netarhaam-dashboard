const express = require('express');
const axios = require('axios');
const https = require('https');
const xml2js = require('xml2js');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = 3000;

// ─────────────────────────────────────────────────────────────
// PKG COMPATIBILITY: Handle packaged vs development mode
// ─────────────────────────────────────────────────────────────

// Detect if running as pkg executable
const isPackaged = typeof process.pkg !== 'undefined';

// Function to get correct file path for pkg
function getStaticPath() {
    if (isPackaged) {
        // When packaged, HTML files are in the same directory as the executable
        return path.dirname(process.execPath);
    }
    // When running from source
    return __dirname;
}

// Override express.static to handle pkg packaging
const staticPath = getStaticPath();
console.log(`[INFO] Static files path: ${staticPath}`);
console.log(`[INFO] Running as packaged executable: ${isPackaged}`);

// Serve static files from the correct location
app.use(express.static(staticPath));

// Middleware for JSON parsing
app.use(express.json());

// Global config storage
let dashboardConfig = {
    firewallIP: '',
    apiKey: '',
    intervalSec: 10,
    internetZone: 'Outside'
};

// Store previous byte counts for bandwidth calculation
let prevSessions = {};

// XML Parser Helper
const parseXml = (xml) => {
    return new Promise((resolve, reject) => {
        xml2js.parseString(xml, { explicitArray: false, trim: true }, (err, result) => {
            if (err) reject(err);
            else resolve(result);
        });
    });
};

// ─────────────────────────────────────────────────────────────
// Route handlers for HTML pages (PKG COMPATIBLE)
// ─────────────────────────────────────────────────────────────

app.get('/', (req, res) => {
    try {
        const filePath = path.join(staticPath, 'index.html');
        console.log(`[ROUTE] Serving index.html from: ${filePath}`);
        
        if (fs.existsSync(filePath)) {
            res.sendFile(filePath);
        } else {
            console.error(`[ERROR] index.html not found at: ${filePath}`);
            res.status(404).send('Configuration page not found');
        }
    } catch (error) {
        console.error('[ERROR] Failed to serve index.html:', error);
        res.status(500).send('Internal server error');
    }
});

app.get('/dashboard.html', (req, res) => {
    try {
        const filePath = path.join(staticPath, 'dashboard.html');
        console.log(`[ROUTE] Serving dashboard.html from: ${filePath}`);
        
        if (fs.existsSync(filePath)) {
            res.sendFile(filePath);
        } else {
            console.error(`[ERROR] dashboard.html not found at: ${filePath}`);
            res.status(404).send('Dashboard page not found');
        }
    } catch (error) {
        console.error('[ERROR] Failed to serve dashboard.html:', error);
        res.status(500).send('Internal server error');
    }
});

// ─────────────────────────────────────────────────────────────
// Generate API Key using POST
app.post('/api/generate-key', async (req, res) => {
    const { firewallIP, username, password } = req.body;

    if (!firewallIP || !username || !password) {
        return res.json({ 
            success: false, 
            msg: 'Firewall IP, username and password are required' 
        });
    }

    try {
        const url = `https://${firewallIP}/api/?type=keygen`;

        console.log('[KEYGEN] Sending POST to:', url);
        console.log('[KEYGEN] Form data:', `user=${username}&password=***`);

        const response = await axios.post(
            url,
            `user=${encodeURIComponent(username)}&password=${encodeURIComponent(password)}`,
            {
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                httpsAgent: new https.Agent({ rejectUnauthorized: false }),
                timeout: 15000
            }
        );

        console.log('[KEYGEN] Status:', response.status);

        const result = await parseXml(response.data);

        // Extract key
        let apiKey = 
            result?.response?.result?.key ||
            result?.response?.result?.['key'] ||
            result?.response?.result?.['#text'] ||
            result?.response?.['result']?.key ||
            result?.response?.['result']?.['#text'] ||
            null;

        if (apiKey) {
            apiKey = apiKey.trim();
        }

        if (apiKey && apiKey.length > 20) {
            res.json({
                success: true,
                apiKey: apiKey,
                msg: 'API key generated successfully'
            });
        } else {
            res.json({
                success: false,
                msg: 'Key generation failed - could not find valid key in response'
            });
        }

    } catch (err) {
        console.error('[KEYGEN ERROR]', err.message);
        if (err.response) {
            console.error('Status:', err.response.status);
            console.error('Response data:', err.response?.data || 'No data');
        }
        res.json({
            success: false,
            msg: err.code === 'ETIMEDOUT' 
                ? 'Connection timeout' 
                : `Request failed: ${err.message}`
        });
    }
});

// ─────────────────────────────────────────────────────────────
// Save configuration + validate existing API key
app.post('/api/save-config', async (req, res) => {
    const { firewallIP, apiKey, intervalSec = 10, internetZone = 'Outside' } = req.body;

    if (!firewallIP || !apiKey) {
        return res.json({ 
            success: false, 
            msg: 'Firewall IP and API Key are both required' 
        });
    }

    dashboardConfig = {
        firewallIP,
        apiKey,
        intervalSec: Number(intervalSec),
        internetZone
    };

    try {
        // Test the API key
        const testCmd = '<show><session><all></all></session></show>';
        const testUrl = `https://${firewallIP}/api/?type=op&cmd=${encodeURIComponent(testCmd)}&key=${apiKey}`;

        console.log('[VALIDATION] Testing API key with session command...');
        
        const testResp = await axios.get(testUrl, {
            httpsAgent: new https.Agent({ rejectUnauthorized: false }),
            timeout: 10000
        });

        console.log('[VALIDATION] Response length:', testResp.data?.length, 'chars');
        
        // Check if response looks valid
        if (!testResp.data || testResp.data.length < 100) {
            return res.json({
                success: false,
                msg: 'Invalid response from firewall - response too short'
            });
        }

        // Check for authentication errors
        if (testResp.data.includes('error') && testResp.data.includes('Invalid credential')) {
            return res.json({
                success: false,
                msg: 'API key validation failed - invalid credentials'
            });
        }

        console.log('[VALIDATION] API key appears valid - got session data');
        
        res.json({
            success: true,
            msg: 'Configuration saved successfully! Redirecting to dashboard...',
            redirect: '/dashboard.html'
        });

    } catch (err) {
        console.error('Save config error:', err.message);
        
        let errorMsg = 'Validation failed';
        if (err.code === 'ETIMEDOUT') {
            errorMsg = 'Connection timeout - check firewall IP and network';
        } else if (err.response) {
            const responseData = err.response.data || '';
            if (responseData.includes('Invalid credential')) {
                errorMsg = 'Invalid API key or credentials';
            } else if (responseData.includes('Access Denied')) {
                errorMsg = 'Access denied - insufficient permissions';
            } else {
                errorMsg = `HTTP ${err.response.status}: ${err.response.statusText}`;
            }
        } else {
            errorMsg = err.message;
        }
        
        res.json({
            success: false,
            msg: errorMsg
        });
    }
});

// ─────────────────────────────────────────────────────────────
// Sessions endpoint with DHCP hostnames and bandwidth calculation
app.get('/api/sessions', async (req, res) => {
    try {
        const { firewallIP, apiKey, intervalSec, internetZone } = dashboardConfig;

        console.log('[SESSIONS] Starting fetch...');

        if (!firewallIP || !apiKey) {
            return res.status(400).json({ 
                error: 'Configuration not complete',
                details: 'Firewall IP or API key missing. Please save configuration first.'
            });
        }

        // --- Fetch sessions ---
        const xmlCmd = `<show><session><all></all></session></show>`;
        const url = `https://${firewallIP}/api/?type=op&cmd=${encodeURIComponent(xmlCmd)}&key=${apiKey}`;
        
        console.log('[SESSIONS] Fetching sessions...');
        
        const sessionResp = await axios.get(url, { 
            httpsAgent: new https.Agent({ rejectUnauthorized: false }),
            timeout: 15000
        });

        console.log('[SESSIONS] Raw response received, length:', sessionResp.data.length, 'chars');
        
        // Check for authentication errors
        if (sessionResp.data.includes('error') && sessionResp.data.includes('Invalid credential')) {
            return res.status(401).json({ 
                error: 'Authentication failed',
                details: 'API key is invalid or expired. Please regenerate API key.'
            });
        }
        
        const sessionResult = await parseXml(sessionResp.data);
        
        // Get entries
        let entries = [];
        if (sessionResult?.response?.result?.entry) {
            entries = sessionResult.response.result.entry;
        } else if (sessionResult?.response?.entry) {
            entries = sessionResult.response.entry;
        } else if (sessionResult?.response?.result && typeof sessionResult.response.result === 'object') {
            const resultKeys = Object.keys(sessionResult.response.result);
            if (resultKeys.includes('entry')) {
                entries = sessionResult.response.result.entry;
            }
        }
        
        if (!entries) entries = [];
        if (!Array.isArray(entries)) entries = [entries];
        
        console.log(`[SESSIONS] Found ${entries.length} total entries`);
        
        // Filter by internet zone
        entries = entries.filter(e => e && (e.from === internetZone || e.to === internetZone));
        
        console.log(`[SESSIONS] ${entries.length} entries after filtering for zone: ${internetZone}`);

        // --- Fetch DHCP leases ---
        let dhcpLeases = {};
        try {
            const dhcpCmd = `<show><dhcp><server><lease><interface>all</interface></lease></server></dhcp></show>`;
            const dhcpUrl = `https://${firewallIP}/api/?type=op&cmd=${encodeURIComponent(dhcpCmd)}&key=${apiKey}`;
            
            console.log('[DHCP] Fetching DHCP leases...');
            
            const dhcpResp = await axios.get(dhcpUrl, { 
                httpsAgent: new https.Agent({ rejectUnauthorized: false }),
                timeout: 10000
            });
            
            const dhcpResult = await parseXml(dhcpResp.data);
            
            if (dhcpResult.response?.result?.interface) {
                let interfaces = dhcpResult.response.result.interface;
                if (!Array.isArray(interfaces)) interfaces = [interfaces];
                interfaces.forEach(intf => {
                    if (!intf.entry) return;
                    let eArr = Array.isArray(intf.entry) ? intf.entry : [intf.entry];
                    eArr.forEach(e => {
                        if (e && e.ip) {
                            dhcpLeases[e.ip] = e.hostname || '';
                        }
                    });
                });
            }
            console.log(`[DHCP] Loaded ${Object.keys(dhcpLeases).length} DHCP leases`);
        } catch (dhcpErr) {
            console.warn('[DHCP] Could not fetch DHCP leases:', dhcpErr.message);
        }

        // --- Map sessions and calculate bandwidth ---
        const allSessions = entries.map((s, idx) => {
            if (!s) return null;
            
            const key = `${s.source || ''}:${s.sport || ''}-${s.dst || ''}:${s.dport || ''}`;
            const byteCount = parseInt(s['total-byte-count']) || 0;
            const prev = prevSessions[key] || 0;
            const delta = Math.max(byteCount - prev, 0);
            prevSessions[key] = byteCount;

            return {
                index: idx + 1,
                source: s.source || 'N/A',
                user: dhcpLeases[s.source] || '',
                dst: s.dst || 'N/A',
                application: s.application || 'N/A',
                proto: s.proto || 'N/A',
                sport: s.sport || 'N/A',
                dport: s.dport || 'N/A',
                from: s.from || 'N/A',
                to: s.to || 'N/A',
                state: s.state || 'N/A',
                byteCount: delta,
                rule: s['security-rule'] || 'N/A'
            };
        }).filter(s => s !== null && s.byteCount > 0);

        // Total bandwidth
        const totalBytes = allSessions.reduce((acc, s) => acc + s.byteCount, 0);
        const totalMbps = ((totalBytes * 8) / 1000000 / intervalSec).toFixed(2);

        // Top 10 talkers
        const talkersMap = {};
        allSessions.forEach(s => {
            if (!talkersMap[s.source]) talkersMap[s.source] = 0;
            talkersMap[s.source] += s.byteCount;
        });

        const topTalkers = Object.keys(talkersMap).map(ip => ({
            ip,
            bytes: talkersMap[ip],
            mbps: ((talkersMap[ip] * 8) / 1000000 / intervalSec).toFixed(2),
            hostname: dhcpLeases[ip] || ''
        })).sort((a, b) => b.bytes - a.bytes).slice(0, 10);

        // Sort sessions by byteCount descending
        allSessions.sort((a, b) => b.byteCount - a.byteCount);

        console.log(`[SESSIONS] Returning ${allSessions.length} active sessions, ${totalMbps} Mbps total`);
        
        res.json({ 
            success: true,
            totalMbps, 
            topTalkers, 
            sessions: allSessions,
            internetZone: internetZone || "Outside",
            intervalSec: intervalSec || 10,
            timestamp: new Date().toISOString()
        });

    } catch (err) {
        console.error('[SESSIONS] Error:', err.message);
        
        if (err.response) {
            console.error('[SESSIONS] Response status:', err.response.status);
            
            if (err.response.data && typeof err.response.data === 'string') {
                if (err.response.data.includes('Invalid credential')) {
                    return res.status(401).json({ 
                        error: 'Authentication failed',
                        details: 'API key is invalid or expired'
                    });
                }
                if (err.response.data.includes('error') || err.response.data.includes('Error')) {
                    return res.status(500).json({ 
                        error: 'Firewall error',
                        details: err.response.data.substring(0, 500)
                    });
                }
            }
        }
        
        res.status(500).json({ 
            error: 'Failed to fetch sessions',
            details: err.message,
            code: err.code || 'UNKNOWN_ERROR'
        });
    }
});

// ─────────────────────────────────────────────────────────────
// Get current configuration
app.get('/api/get-config', (req, res) => {
    res.json({
        success: true,
        config: dashboardConfig
    });
});

// ─────────────────────────────────────────────────────────────
// Clear previous sessions data
app.post('/api/clear-cache', (req, res) => {
    prevSessions = {};
    res.json({ success: true, msg: 'Bandwidth cache cleared' });
});

// ─────────────────────────────────────────────────────────────
// Health check endpoint
app.get('/health', (req, res) => {
    res.json({ 
        status: 'OK', 
        timestamp: new Date().toISOString(),
        isPackaged: isPackaged,
        config: dashboardConfig.firewallIP ? 'Configured' : 'Not Configured'
    });
});

// ─────────────────────────────────────────────────────────────
// Start server
app.listen(PORT, '0.0.0.0', () => {
    console.log(`╔══════════════════════════════════════════════════════════╗`);
    console.log(`║ 🔥 NetArhaam™ PA Live Dashboard                         ║`);
    console.log(`║ 📍 Running at: http://localhost:${PORT}                 ║`);
    console.log(`║ 📍 Also accessible at: http://[YOUR-IP]:${PORT}         ║`);
    console.log(`║ 📁 Static path: ${staticPath}                           ║`);
    console.log(`║ 📦 Packaged: ${isPackaged}                              ║`);
    console.log(`╚══════════════════════════════════════════════════════════╝`);
    console.log(`📝 Available endpoints:`);
    console.log(`   GET  /                 - Configuration page`);
    console.log(`   GET  /dashboard.html   - Live dashboard`);
    console.log(`   GET  /health           - Health check`);
    console.log(`   POST /api/generate-key - Generate API key`);
    console.log(`   POST /api/save-config  - Save configuration`);
    console.log(`   GET  /api/sessions     - Get live sessions data`);
    console.log(`   GET  /api/get-config   - Get current configuration`);
    console.log(`   POST /api/clear-cache  - Clear bandwidth cache`);
    console.log(``);
    console.log(`⚠️  Press Ctrl+C to stop the server`);
    console.log(``);
});

